"""
Module for data utility functions used in Enginer 1858.
"""

# Data Manipulation
import numpy as np
import pandas as pd

# Raster Manipulation
import rasterio

# Import os
import os


def build_train_set(numeric_df,
                    land_df,
                    unreliable_df,
                    all_columns,
                    tag_dict):
    """ Build Training Dataset

    Args:
        numeric_df (pd DataFrame): DataFrame of the original CSV data.
        land)df (pd DataFrame): derived raster data.

    Returns:
        complete_train_df (pd DataFrame): DataFrame of joined training data.
    """
    # Part 1: Subset the rows based only those that are known to be reliable
    # subset numeric
    numeric_df = numeric_df[numeric_df['reliability_txt']
                            == 'High reliability']

    # subset the same indicies in the land df
    land_df = land_df.iloc[land_df.index.tolist(), :]

    # Part 2: Adjust Time Column if Included
    if 'survey_start_date' in numeric_df.columns.tolist():

        # convert to dt index
        time = pd.DatetimeIndex(numeric_df['survey_start_date'])

        # drop the time column
        numeric_df.drop('survey_start_date', inplace=True, axis=1)

        # add month and year to the df
        numeric_df['year'] = time.year
        numeric_df['month'] = time.month_name()

        # update the tag_dict - filter binary then add month name
        tag_dict['binary'] = list(filter(
            lambda x: x != 'survey_start_date', tag_dict['binary']))

        tag_dict['binary'].append('month')

        # if integer cols include year else make it
        if 'integer' in tag_dict:
            tag_dict['integer'].append('year')
        else:
            tag_dict['integer'] = ['year']

    # Part 3: Reindex both since small
    numeric_df.index = np.arange(numeric_df.shape[0])
    land_df.index = np.arange(land_df.shape[0])

    # Part 4: Make the concatenation for the reliable df
    reliable_df = pd.concat([numeric_df, land_df], axis=1)

    # lower reliable columns - ugly so remove eventually
    # Lower column names
    cols = reliable_df.columns.tolist()
    for i, col in enumerate(cols):
        cols[i] = col.lower()

    reliable_df.columns = cols

    # Part 5: Subset the columns of the unreliable df and concat vertically
    unreliable_df = unreliable_df[reliable_df.columns.tolist()]

    # Part 6: Training Data
    training_data = pd.concat([reliable_df, unreliable_df], axis=0)

    all_columns = training_data.columns.tolist()

    # Add new cols to tag dict
    # new_cols = ['ecoregion1750',
    #             'sept2014JulMinTemp',
    #             'sept2014JulRainfall',
    #             '75m_dem_streams_burned_sept2012',
    #             'log_vertical_distance_saline_wetlands_sept2012',
    #             'vegtype3_4',
    #             'ibra_hex',
    #             'Anisotrophic_Heating_Ruggedness',
    #             'sept2014JanMaxTemp',
    #             'sept2014JanRainfall',
    #             'land_cov_use3',
    #             'ecoregion2014']

    # tag_dict['continuous'].extend(new_cols)

    return training_data, all_columns, tag_dict


def raster_lookup(xmat_prime,
                  files_list,
                  prefix,
                  lat_col='latitudedd_num',
                  lon_col='longitudedd_num'):
    """ Build the feature vectors for eventual matrix entry

    Args:
        xmat_prime (dict): obervation to predict on.
        files_list (list): list of the files.
        prefix (str): string prefix to the files.

    Returns:
        sample_dict (dict): dictionary with the sample in it.
    """
    # make a new df to store the coordinates
    xmat_prime_cords = pd.DataFrame()

    # co-ordinate collection
    xmat_prime_cords['cords'] = \
        tuple(zip(xmat_prime[lat_col],
                  xmat_prime[lon_col]))

    # for each raster
    for _, file in enumerate(files_list):

        # open that raster
        with rasterio.open(os.path.join(prefix, file)) as src:

            # read in the underlying array
            raster_array = src.read(1)

            long_vec = []

            # for each row
            for i, row in xmat_prime_cords.iterrows():

                # Extract coordinate components
                x_pos = row[0][0]
                y_pos = row[0][1]

                # Sample Lookup
                comp_cord = src.index(y_pos, x_pos)  # [::-1]

                # obtain the value for that sample point
                val = raster_array[comp_cord[0],
                                   comp_cord[1]]

                # append that value to the feature vector
                long_vec.append(val)

        # Make this now part of the DF
        xmat_prime[file.split('.')[0]] = long_vec

        print('Finished:', file)

    # Finalisation - drop lat and lon cols
    # xmat_prime.drop(lat_col, axis=1, inplace=True)
    # xmat_prime.drop(lon_col, axis=1, inplace=True)

    return xmat_prime
