"""
Stores the utilities needed by the model object.
"""

# Data Manipulation
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split

# ==============================================================================
#                               Splitter
# ==============================================================================


def splitter(split_type,
             data,
             target_col,
             test_size,
             stratify,
             validation_size=None,
             random_state=27):
    """ Splitter

    Notes:
        The validatiob=n set will be a proportion of the
        initial train set so please factor this into
        consideration.

    Args:
        split_type (str in {'tt', 'tvt'}): use `tvt` if validation set.

        target_col (str): target column as string name.

        xmat (pd DataFrame): design matrix.
        y (pd Series): response vector.
        test_size (float or int): size of test.
        validation_size (Optional. None or int or float on [0, 1]):
                        the size of the validation set meaningless if
                        `split_type` != 'tvt'.
        random_state (int): random state for consistency over splits.

    Returns:
        portion_dictionary (dict): all pieces from splitting. Either
                                    4 or 6.
    """
    # Part 1: Envrionment
    portion_dictionary = dict()

    print('Final', data[stratify]['reliability_txt'].value_counts())

    # Part 2: Run train-test as normal
    xmat_train, xmat_test = \
        train_test_split(data,
                         test_size=validation_size,
                         stratify=data[stratify],
                         random_state=random_state)

    # Part 3: If Validation set to be made make it now
    if split_type == 'tvt':
        xmat_train, xmat_validate = train_test_split(xmat_train,
                                                     test_size=test_size,
                                                     stratify=xmat_train[stratify],
                                                     random_state=random_state)

        # Assign into return dictionary immediately
        portion_dictionary['y_validate'] = xmat_validate[target_col]
        xmat_validate = xmat_validate.drop(target_col, axis=1)  # Explicit Drop
        portion_dictionary['xmat_validate'] = xmat_validate

        # Save Indicies
        portion_dictionary['validate_indicies'] = xmat_validate.index.tolist()

    # Place in dictionary for return
    portion_dictionary['y_train'] = xmat_train[target_col]
    xmat_train = xmat_train.drop(target_col, axis=1)            # Explicit Drop
    portion_dictionary['xmat_train'] = xmat_train

    # Save Indicies
    portion_dictionary['train_indicies'] = xmat_train.index.tolist()

    portion_dictionary['y_test'] = xmat_test[target_col]
    xmat_test = xmat_test.drop(target_col, axis=1)              # Explicit Drop
    portion_dictionary['xmat_test'] = xmat_test

    # Save Indicies
    portion_dictionary['test_indicies'] = xmat_test.index.tolist()

    return portion_dictionary

# ==============================================================================
#                               Reset Indicies
# ==============================================================================


def reset_indicies(data_dict):
    """ Reset Indicies to 1, ..., n

    Args:
        data_dict (dict): dictionary of datasets.

    Returns:
        data_dict
    """
    for dataset_name, data in data_dict.items():

        # Try and make its index new otherwise pass
        try:
            data.index = np.arange(data.shape[0]).tolist()
        except:
            print(data[:5])

        data_dict[dataset_name] = data

    return data_dict


# ==============================================================================
#                               Model SwitchOut
# ==============================================================================


def switch_out_models(model_dict_list, model_object_dict):
    """ Switch Model

    Args:
        model_dict_list (list(dict)): list of model configuration dictionaries where the key is 'classifier'.

    Example:
        [{'classifier': {'model': 'svm', 'fixed_args': {'gamma': 'scale'}},
            'classifier__C': [0.1, 0.5, 1, 5, 10, 20, 50, 100],
            'classifier__kernel': ['linear', 'poly', 'rbf', 'sigmoid']}]

    Returns:

    """
    # Dict of Models
    for _, model_dict in enumerate(model_dict_list):

        model_object = model_object_dict[model_dict['classifier']['model']]
        fixed_args = model_dict['classifier']['fixed_args']

        model_dict['classifier'] = [model_object(**fixed_args)]

    return model_dict_list


# ==============================================================================
#                               Scaling SwitchOut
# ==============================================================================

def switch_out_scalers(scaler_dict, scaler_object_dict):
    """ Switch Out Scalers

    Args:
        scaler_dict (dict): dictionary of scaler inputs.
        scaler_object_dict (dict): dict of scaler objects.

    Returns:
        dictionary (dict): dict of scaler objects.
    """
    # New list to store scaler objects
    object_list = []

    # For each scaler string that is sitting where the object needs to be
    for _, scaler_name in enumerate(scaler_dict['scaler']):
        scaler_object = scaler_object_dict[scaler_name]
        object_list.append(scaler_object())

    # Set the list with the objects to be the value in the scaler list dict
    scaler_dict['scaler'] = object_list

    return scaler_dict

# ==============================================================================
#                               Dimensionality Reduction SwitchOut
# ==============================================================================


def switch_out_dim_red(dim_reduction_dict, dim_reduction_objects):
    """  Switch out dimensionalty reduction methods.

    Args:
        dim_reduction_dict (dict): dictionary of dimensionality reduction arguments.
        dim_reduction_objects (dict): dict of dimensionality reduction techniques.

    Returns:

    """
    # Dict of Models
    #     dim_reduction_dict = dict(none=IdentityTransformer,
    #                               pca=PCA)

    # New list to store scaler objects
    object_list = []

    # For each scaler string that is sitting where the object needs to be
    for i, dim_red_name in enumerate(dim_reduction_dict['reduce_dim']):
        dim_red_object = dim_reduction_objects[dim_red_name]
        object_list.append(dim_red_object())

    # Set the list with the objects to be the value in the scaler list dict
    dim_reduction_dict['reduce_dim'] = object_list

    return dim_reduction_dict
