"""
Module for the model object, the main workhorse of the API.
"""
from copy import deepcopy
from functools import reduce

# Data Manipulation
import numpy as np
import pandas as pd

# Pipeline
from sklearn.pipeline import Pipeline

# Pre-Processing Transformers
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler, MinMaxScaler, QuantileTransformer

# Models
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import LogisticRegression
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis
from sklearn.neighbors import KNeighborsClassifier, RadiusNeighborsClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, GradientBoostingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
import lightgbm as lgb
import xgboost as xgb

# Dimensionality Reduction
from sklearn.decomposition import PCA

# Custom Transformer Imports
from engine_1858.custom_transformers import IdentityTransformer
from engine_1858.custom_transformers import make_parameter_grids
from engine_1858.custom_transformers import CleanseConsolidatePipeline
from engine_1858.data_utils import build_train_set, raster_lookup

# Splitter
from engine_1858.model_utils import splitter, switch_out_scalers, switch_out_models, switch_out_dim_red, reset_indicies

# Hyperparameter Tuning
from sklearn.model_selection import RandomizedSearchCV


class DWELPModel:
    """ Class to enable model training estimation, tuning and prediction.
    """

    def __init__(self,
                 data,
                 land_df,
                 unreliable_df,
                 tag_dict,
                 configuration_dict,
                 cc_pipe_kwargs,
                 split_type,
                 split_kwargs):
        """ Init method/

        Notes:
            data_tags should be droppable straight into LDConditionalImputer.

        Args:
            data (pd DataFrame): Pandas datra frame.
            tag_dict (dict): type of column is key e.g. binary and value is list
                             of that type.
            configuration_dict (dict): dictionary of the
            cc_pipe_kwargs (dict): arguments to the pipe for cleansing and consolidation.
            split_type (None or str in {'tt', 'tvt'}): None is no split. `tt` is train-test.
                                                       `tvt` is train-validation-test.
            split_args (dict): arguments to the split function.

        Returns:
            None. Python init method.
        """
        # Part 1: Allocate all Arguments
        self. data = data
        self.tag_dict = tag_dict
        self.configuration_dict = configuration_dict

        # Part 1: Drop all uneeded columns
        all_columns = reduce(lambda x, y: x + y, list(tag_dict.values()), [])
        xmat_y = data[all_columns]
        tag_dict['id'] = tag_dict['id'][0]  # Was single element list now str

        # Adjusted ----------------
        xmat_y, all_columns, tag_dict = build_train_set(xmat_y,
                                                        land_df,
                                                        unreliable_df,
                                                        all_columns,
                                                        tag_dict)

        self.survey_flag = False
        if 'survey_start_date' not in all_columns:

            self.survey_flag = True

            for _, op in enumerate(cc_pipe_kwargs['fit_arg_list']):

                if 'binary_columns' in op:
                    op['binary_columns'] = list(filter(
                        lambda x: x != 'survey_start_date', op['binary_columns']))
                    op['binary_columns'].append('month')

        # Reset the index
        xmat_y.index = np.arange(xmat_y.shape[0])

        self.cols = xmat_y.drop(tag_dict['target'][0], axis=1).columns.tolist()
        # Adjusted ----------------

        # Part 2: Pre-Process the Target and Cut Down Design Matrix
        # Identify Present and Missing Indicies and Now Use Only Present
        y_col = tag_dict['target'][0]
        missing_y = xmat_y[xmat_y[y_col].isna() == True].index.tolist()
        present_y = xmat_y.loc[xmat_y[y_col].isna() == False, :].index.tolist()

        xmat_y = xmat_y.iloc[present_y, :]  # To Keep

        # Adjust target variable to be non-numeric - ADJUSTED
        xmat_y[y_col] = xmat_y[y_col].apply(
            lambda x: 0 if x == 'High reliability' else 1)

        # Part 3: Test if Train-Test
        self.split_type = split_type    # This will allow O(1) lookup later

        # Case 1: No Splitting
        if split_type is None:
            self.datasets = dict(data=xmat_y)

        # Case 2: Either tt or tvt
        elif split_type is not None:
            self.datasets = splitter(split_type=split_type,
                                     data=xmat_y,
                                     target_col=tag_dict['target'][0],
                                     **split_kwargs)

            self.debug_db = deepcopy(self.datasets)

        # Make sure to reset indicies to prevent concat complications later
        self.datasets = reset_indicies(self.datasets)

        # Part 4: Perform the Pre-Processing and Consolidation
        # By default need to create the pipeline for cleansing and consolidation
        self.cleanse_console_pipe = \
            CleanseConsolidatePipeline(**cc_pipe_kwargs)

        self.cleanse_console_pipe.pre_process(self.datasets['xmat_train'])
        self.datasets['xmat_train'] = self.cleanse_console_pipe.transformed_original

        # Case 2: Train-Test - Fit Out the test set
        if self.split_type is not None:
            self.datasets['xmat_test'] = self.cleanse_console_pipe.apply(
                self.datasets['xmat_test'])

            # Case 3: Train-Validation-Test Case - Need to adjust validate as well
            if split_type == 'tvt':
                self.datasets['xmat_validate'] = self.cleanse_console_pipe.apply(
                    self.datasets['xmat_validate'])

            # Store in Training Anticiapation
        self.model_pipe = None
        self.rs_obs = None

    def train(self):
        """ Train Models

        Args:
            None. All arguments are specified on instantiation.

        Returns:
            None. Sets post training attributes within the class.
        """
        # Environment

        # Scaler Dict
        scaler_object_dict = dict(none=IdentityTransformer,
                                  standard=StandardScaler,
                                  minmax=MinMaxScaler,
                                  quantile=QuantileTransformer)

        # Dimension Reduction Dict
        dim_reduction_dict = dict(none=IdentityTransformer,
                                  pca=PCA)

        # Model Dict
        model_object_dict = dict(svm=SVC,
                                 knn=KNeighborsClassifier,
                                 rnn=RadiusNeighborsClassifier,
                                 rf=RandomForestClassifier,
                                 nb=GaussianNB,
                                 lr=LogisticRegression,
                                 lda=LinearDiscriminantAnalysis,
                                 qda=QuadraticDiscriminantAnalysis,
                                 cart=DecisionTreeClassifier,
                                 gbm=GradientBoostingClassifier,
                                 lgb_=lgb.LGBMClassifier,
                                 xgb_=xgb.XGBClassifier,
                                 adaboost=AdaBoostClassifier,
                                 neural_net=MLPClassifier)

        # Unload Configuration Parameters
        search_parameters = self.configuration_dict['search_parameters']

        # Case 1: Search Configuration Dict is Empty ----------------------------------------------
        if not len(search_parameters):

            simple_pipe = Pipeline([('scaler', scaler_object_dict[self.configuration_dict['scaler']]()),
                                    ('reduce_dim',
                                     dim_reduction_dict[self.configuration_dict['scaler']]()),
                                    ('classifier', model_object_dict[self.configuration_dict['scaler']]())])

            simple_pipe.fit(self.datasets['xmat_train'],
                            self.datasets['y_train'])

            self.model_pipe = simple_pipe
            print('Training Complete')

        # Case 2: Search Configuration not Empty --------------------------------------------------
        else:

            # Part 1: Switch out names for objects
            self.configuration_dict['scaler_set'] = \
                switch_out_scalers(
                    self.configuration_dict['scaler_set'], scaler_object_dict)

            self.configuration_dict['dimensionality_reduction_set'] = \
                switch_out_dim_red(
                    self.configuration_dict['dimensionality_reduction_set'], dim_reduction_dict)

            self.configuration_dict['model_config_list'] = \
                switch_out_models(
                    self.configuration_dict['model_config_list'], model_object_dict)

            # Part 2: Make the Grid
            constant_grids = [self.configuration_dict['scaler_set'],
                              self.configuration_dict['dimensionality_reduction_set']]

            competing_grids = [self.configuration_dict['model_config_list']]

            meta_grid = make_parameter_grids(constant_grids, competing_grids)

            # Part 3: Set a Default Pipe - No scaling or Dim Reg with Naive Bayes as Default Model
            base_pipe = Pipeline([('scaler', IdentityTransformer()),
                                  ('reduce_dim', IdentityTransformer()),
                                  ('classifier', GaussianNB())])

            # Part 3: Estimation
            rs_obs = []

            for _, grid in enumerate(meta_grid):

                randsearch = RandomizedSearchCV(base_pipe,
                                                grid,
                                                **self.configuration_dict['search_parameters']).fit(self.datasets['xmat_train'],
                                                                                                    self.datasets['y_train'])

                rs_obs.append(randsearch)

            print('Training Complete')
            self.rs_obs = rs_obs

            # Part 4: Iterate Model Outputs and Get the Best Model and Set as model_pipe
            best_score = 0
            for _, candidate_model in enumerate(rs_obs):

                # Does this model have a better score? If so set as best and make model, model pipe
                if candidate_model.best_score_ > best_score:
                    best_score = candidate_model.best_score_
                    self.model_pipe = candidate_model

            print('Best Score from Chosen Models is:', best_score)

    def predict(self,
                xmat_prime,
                prediction_type='probability',
                already_processed=False,
                prefix='/home/mordata95/main/s22019/DELWP_Team14/spatial/raster_store2'):
        """ Prediction Function

        Args:
            xmat_prime (pd DataFrame): unseen matrix to predict. Must have all same
                                        columns as the training matrix.
            prediction_type (str in {'classification', 'probability', 'log_probability'}):
                            Whether to return the predicted classification, probability or
                            log_probability. Preference is probability based on DELWP
                            description of API usage.
            already_processed (bool): indicates that pre-processing has already been undertaken.
                                      Set this flag if you would like to predict on the test set above.

        Returns:
            prediction_probabilities (pd Series): Vector of probabilities of being Unreliable.
        """
        # Part 1: New Adjustments
        # 1.1 - Lookup lat and long to give new values
        # Here the rasters need to be looked up
        if already_processed == False:

            files_list = ['ecoregion1750.tif',
                          'sept2014JulMinTemp.tif',
                          'sept2014JulRainfall.tif',
                          '75m_dem_streams_burned_sept2012.tif',
                          'log_vertical_distance_saline_wetlands_sept2012.tif',
                          'vegtype3_4.tif',
                          'ibra_hex.tif',
                          'Anisotrophic_Heating_Ruggedness.tif',
                          'sept2014JanMaxTemp.tif',
                          'sept2014JanRainfall.tif',
                          'land_cov_use3.tif',
                          'ecoregion2014.tif']

            xmat_prime = raster_lookup(xmat_prime,
                                       files_list,
                                       prefix)

            cols = xmat_prime.columns.tolist()
            for i, col in enumerate(cols):
                cols[i] = col.lower()

            xmat_prime.columns = cols

            # 1.2 - If date and date changed using flag above, then change
            # Part 2: Adjust Time Column if Included
            if self.survey_flag:

                # convert to dt index
                time = pd.DatetimeIndex(xmat_prime['survey_start_date'])

                # drop the time column
                try:
                    xmat_prime.drop('survey_start_date', inplace=True, axis=1)
                except:
                    print('Never in there man')

                # add month and year to the df
                xmat_prime['year'] = time.year
                xmat_prime['month'] = time.month_name()

            # Part 2: Apply Pre-Processing Transformation
            new_xmat_prime = pd.DataFrame()
            col_list = xmat_prime.columns.tolist()
            for i, col in enumerate(col_list):

                if col in self.cols:
                    new_xmat_prime[col] = xmat_prime[col]

            xmat_prime = new_xmat_prime

        # if already_processed == False:
            xmat_prime = self.cleanse_console_pipe.apply(xmat_prime)

        # Part 3: Prediction
        # Case 1: Probability of Unreliable
        if prediction_type == 'probability':
            return self.model_pipe.predict_proba(xmat_prime)

        # Case 2: Prediction of Unreliable
        elif prediction_type == 'classification':
            return self.model_pipe.predict(xmat_prime)

        # Case 3: Log Probability of Unreliable
        elif prediction_type == 'log_probability':
            return self.model_pipe.log_probability(xmat_prime)
