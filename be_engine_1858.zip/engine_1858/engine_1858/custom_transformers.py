"""
This module contains custom transformers and pre-processing operations used to
facilitate the modelling API.
"""
# Native
from copy import deepcopy

# Data Manipulation
import numpy as np
import pandas as pd

from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder

# ==============================================================================
#                               Identity Transformer
# ==============================================================================


class IdentityTransformer(TransformerMixin, BaseEstimator):
    """

    Notes:
        Designed for when when user inputs the transformation as None.
    """

    def __init__(self):
        pass

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        return X


# ==============================================================================
#                               Conditional Imputer
# ==============================================================================
class LDConditionalImputer:
    """ Conditional Imputer Class
    """

    def __init__(self, tag_dict, conditioning_column):
        """

        Args:
            tag_dict (dict): see engine_1858_guide for guidance.
            conditioning_column ():


        """
        # Store Imputer Arguments
        self.imputer_args = dict(binary=dict(strategy='most_frequent'),
                                 date_time=dict(strategy='most_frequent'),
                                 integer=dict(strategy='median'),
                                 continuous=dict(strategy='mean'))\

        self.conditioning_column = conditioning_column
        self.levels = None
        self.imputer_set = dict()
        self.tag_dict = tag_dict

        self.do_not_try_to_impute = {
            'id', 'target'}  # Do not try and impute the following

    def pre_process(self, data):
        """


        """
        self.levels = data[self.conditioning_column].unique().tolist()

        print('Hey Hey', data.columns)

        for feature_type, feature_list in self.tag_dict.items():

            level_dict = dict()

            if feature_type not in self.do_not_try_to_impute:

                for _, level in enumerate(self.levels):

                    level_dict[level] = SimpleImputer(**self.imputer_args[feature_type]).\
                        fit(data.loc[data[self.conditioning_column]
                                     == level, feature_list])

            self.imputer_set[feature_type] = level_dict
        print('Conditional Imputer Pre-Processing Complete')

    def apply(self, data):
        """

        """
        for feature_type, feature_list in self.tag_dict.items():

            if feature_type not in self.do_not_try_to_impute:

                for _, level in enumerate(self.levels):

                    to_impute = data.loc[data[self.conditioning_column]
                                         == level, feature_list]

                    imputation_result = self.imputer_set[feature_type][level].transform(
                        to_impute)

                    try:
                        data.loc[data[self.conditioning_column] ==
                                 level, feature_list] = imputation_result

                    except:

                        raise Exception('When conditioning on {0} one of the following features had no values {1}.\
                                        You need to check which of these is responsibel and consider excluding it.'.
                                        format(level, to_impute.columns.tolist()))

        return data


# ==============================================================================
#                               Binariser
# ==============================================================================
class LDBinariser:
    """ Binarisation class.
    """

    def __init__(self, binary_columns, id_col=False):
        """ Initialise class

        Args:
            binary_columns (list): columns which are binary.
            id_col (str): the id column of the class.

        Returns:
            None.
        """
        self.binariser = None
        self.binary_columns = binary_columns
        print('Binary Set', self.binary_columns)
        self.binary_columns.append(id_col)

    def pre_process(self, data):
        """ Pre-Process Training Data

        Args:
            data (pd DataFrame): pandas dataframe.

        Returns:
            None.
        """
        self.binary_columns = self.binary_columns
        self.binariser = OneHotEncoder(
            handle_unknown='ignore').fit(data[self.binary_columns])

    def apply(self, data):
        """ Apply to Test Data

        Args:
            data (pd DataFrame): pandas dataframe.

        Returns:
            None.
        """
        t_d = self.binariser.transform(data[self.binary_columns]).toarray()

        binary_df = pd.DataFrame(t_d,
                                 columns=self.binariser.get_feature_names().tolist())

        data.drop(self.binary_columns, axis=1, inplace=True)

        master_df = pd.DataFrame(
            pd.concat([data, binary_df], axis=1, join='inner'))

        return master_df


# ==============================================================================
#                      Cleanse and Consolidate Pipeline
# ==============================================================================


class CleanseConsolidatePipeline:

    def __init__(self,
                 fit_arg_list,
                 transformations_name=['conditional_imputer', 'binariser']):
        """ Initalise Ckeanse and Consolidate

        Args:
            fit_arg_list ([dict]): list of dictionaries where
                                   element `i` contains the pre_process
                                   arguments to element `i`.

        Returns:
            None.
        """
        # Part 1: Environment and Transformer Dictionary
        self.transformer_dict = dict(conditional_imputer=LDConditionalImputer,
                                     binariser=LDBinariser)

        self.transformations_name = transformations_name
        self.pipe = []
        self.transformed_original = None

        # Part 2: Create Pipe Object
        for i, transfomer in enumerate(transformations_name):
            self.pipe.append(
                self.transformer_dict[transfomer](**fit_arg_list[i]))

    def pre_process(self,
                    xmat):
        """ Pre-Process the training data

        Args:
            xmat (pd DataFrame): training data.

        Returns:
            None.
        """
        self.transformed_original = deepcopy(xmat)
        for _, transformer in enumerate(self.pipe):
            transformer.pre_process(self.transformed_original)
            self.transformed_original = transformer.apply(
                self.transformed_original)
        print("Pre-Processing Complete...")

    def apply(self,
              new_xmat):
        """ Apply Transformations to Design Matrix

        Args:
            new_xmat (pd DataFrame): the new design matrix.

        Returns:

        """
        print("Fitting design matrix ...")
        second_copy = deepcopy(new_xmat)

        for _, transformer in enumerate(self.pipe):
            second_copy = transformer.apply(second_copy)

        print("Fitting Complete ...")

        return second_copy

# ==============================================================================
#                               Parameter Grid Maker
# ==============================================================================


def make_parameter_grids(constant_level_grids, competing_level_grids):
    """ Parameter Grids for Tuning SKLearn Pipes

    Function to make SKLearn parameter tuning grids.

    Args:
        constant_level_grids ([dict]): list of dictionaries to be placed in all grids.
        competing_level_grids ([[dict]]): list of all competing grids where an inner list defines the related
                                        component in the pipe. Thy are called competing because they are being
                                        tuned and support the same aspect of the pipe.

    Returns:
          meta_grid ([dict]):
    """
    # Part 1: Calculate the required number of grids
    total_grid_count = 1
    for _, grid in enumerate(competing_level_grids):
        total_grid_count *= len(grid)

    # Part 2: Make the required number of grids
    meta_grid = []
    for i in range(total_grid_count):
        meta_grid.append({})

    # Part 3: Enumerate the meta_grid and put in the constant sub grids
    for i, sub_grid in enumerate(meta_grid):
        for j, level_grid in enumerate(constant_level_grids):
            sub_grid.update(level_grid)

    # Part 4: Enumerate competing grids
    for i, level_grid_container in enumerate(competing_level_grids):
        level_grid_size = len(level_grid_container)
        for j, sub_grid in enumerate(meta_grid):
            sub_grid.update(level_grid_container[j % level_grid_size])

    return meta_grid
