"""
Module for backend unit tests.
"""
# Vanilla
from copy import deepcopy

# Import Data Manipulation
import numpy as np
import pandas as pd

# Import Testing Framework
import unittest
from numpy.testing import assert_array_equal

# Pipeline Models
from sklearn.naive_bayes import GaussianNB                                 # Base
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from lightgbm import LGBMClassifier
from xgboost import XGBClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis


# Test Components
from engine_1858.custom_transformers import IdentityTransformer, LDConditionalImputer, \
    LDBinariser, CleanseConsolidatePipeline, make_parameter_grids




class TestCustomTransformers(unittest.TestCase):
    """ Class to Test Custom Transformers """

    # Set Test Data
    test_xmat = pd.DataFrame([[12, 15, 6.3, np.nan, 1],
                              [7, 2, np.nan, 1, 1],
                              [np.nan, 5, 12.1, 1, 1],
                              [3, np.nan, 6.1, 0, 1],
                              [12, 15, 6.3, np.nan, 2],
                              [7, 2, np.nan, 1, 2],
                              [np.nan, 5, 12.1, 1, 2],
                              [3, np.nan, 6.1, 0, 2]],
                             columns=['c0', 'c1', 'c2', 'c3', 'species'])

    imputted = pd.DataFrame([[12.0, 15.0, 6.3, 1.0, 1.0],
                             [7.0, 2.0, 8.166666666666666, 1.0, 1.0],
                             [7.0, 5.0, 12.1, 1.0, 1.0],
                             [3.0, 5.0, 6.1, 0.0, 1.0],
                             [12.0, 15.0, 6.3, 1.0, 2.0],
                             [7.0, 2.0, 8.166666666666666, 1.0, 2.0],
                             [7.0, 5.0, 12.1, 1.0, 2.0],
                             [3.0, 5.0, 6.1, 0.0, 2.0]],
                            columns=['c0', 'c1', 'c2', 'c3', 'species'])

    tag_dict = dict(binary=['c3'],
                    continuous=['c2'],
                    integer=['c0', 'c1'])

    # Test 1 - Identity Transformer
    def test_identity_transformer(self, data=test_xmat):
        """ Test Identity Transfomer. """
        # Instantiate
        transformer = IdentityTransformer()

        # Fit
        transformer.fit(data)

        # Transform
        out = transformer.transform(data)

        # Assertion
        assert_array_equal(out, data)

    # Test 2 - Conditional Imputer
    def test_conditional_imputer(self, data=test_xmat, tag_dict=deepcopy(tag_dict)):
        """ Test the Conditional Imputer """

        # Instantiate
        transformer = LDConditionalImputer(tag_dict, 'species')

        # Fit
        transformer.pre_process(data)

        # Transform
        out = transformer.apply(data)

        # Assertion
        compare_to = np.array([[12.0, 15.0, 6.3, 1.0, 1.0],
                               [7.0, 2.0, 8.166666666666666, 1.0, 1.0],
                               [7.0, 5.0, 12.1, 1.0, 1.0],
                               [3.0, 5.0, 6.1, 0.0, 1.0],
                               [12.0, 15.0, 6.3, 1.0, 2.0],
                               [7.0, 2.0, 8.166666666666666, 1.0, 2.0],
                               [7.0, 5.0, 12.1, 1.0, 2.0],
                               [3.0, 5.0, 6.1, 0.0, 2.0]])
        assert_array_equal(out.values, compare_to)

    # Test 3 - Binariser
    def test_binariser(self, data=imputted, tag_dict=deepcopy(tag_dict)):
        """ Test the Binariser """

        # Instantiate
        transformer = LDBinariser(tag_dict['binary'], id_col='species')

        # Fit
        transformer.pre_process(data)

        # Transform
        out = transformer.apply(data)

        # Assertion
        compare_to = np.array([[12.0, 15.0, 6.3, 0.0, 1.0, 1.0, 0.0],
                               [7.0, 2.0, 8.166666666666666, 0.0, 1.0, 1.0, 0.0],
                               [7.0, 5.0, 12.1, 0.0, 1.0, 1.0, 0.0],
                               [3.0, 5.0, 6.1, 1.0, 0.0, 1.0, 0.0],
                               [12.0, 15.0, 6.3, 0.0, 1.0, 0.0, 1.0],
                               [7.0, 2.0, 8.166666666666666, 0.0, 1.0, 0.0, 1.0],
                               [7.0, 5.0, 12.1, 0.0, 1.0, 0.0, 1.0],
                               [3.0, 5.0, 6.1, 1.0, 0.0, 0.0, 1.0]])

        assert_array_equal(out.values, compare_to)

    # Test 4 - Pipeline
    def test_pipeline(self, data=test_xmat, tag_dict=deepcopy(tag_dict)):
        """ Test the Pipeline """

        # Part 1: Set Environment
        imputter_args = dict(tag_dict=tag_dict,
                             conditioning_column='species')

        binariser_args = dict(binary_columns=tag_dict['binary'],
                              id_col='species')

        cc_pipe_kwargs = dict(fit_arg_list=[imputter_args, binariser_args])

        # Part 2: Fire the Cleanse and Consolidate Pipeline
        pipeline = CleanseConsolidatePipeline(**cc_pipe_kwargs)

        pipeline.pre_process(data)

        out = pipeline.apply(data)

        # Part 3: Run the Test
        # Assertion
        compare_to = np.array([[12.0, 15.0, 6.3, 0.0, 1.0, 1.0, 0.0],
                               [7.0, 2.0, 8.166666666666666, 0.0, 1.0, 1.0, 0.0],
                               [7.0, 5.0, 12.1, 0.0, 1.0, 1.0, 0.0],
                               [3.0, 5.0, 6.1, 1.0, 0.0, 1.0, 0.0],
                               [12.0, 15.0, 6.3, 0.0, 1.0, 0.0, 1.0],
                               [7.0, 2.0, 8.166666666666666, 0.0, 1.0, 0.0, 1.0],
                               [7.0, 5.0, 12.1, 0.0, 1.0, 0.0, 1.0],
                               [3.0, 5.0, 6.1, 1.0, 0.0, 0.0, 1.0]])

        assert_array_equal(out.values, compare_to)

    # Test 5 - Parameter Grid Creation
    def test_parameter_grid_creation(self, ):
        """ Test Parameter Grid Creation """
        # Set Test Grids
        constant_grids =  [{'scaler': [IdentityTransformer()]}, {'reduce_dim': [IdentityTransformer()]}]

        competing_grids = [[{'classifier': [LogisticRegression(C=1.0, class_weight=None, dual=False, fit_intercept=True,
                   intercept_scaling=1, l1_ratio=None, max_iter=100,
                   multi_class='warn', n_jobs=None, penalty='l2',
                   random_state=27, solver='warn', tol=0.0001, verbose=0,
                   warm_start=False)], 'classifier__penalty': ['l1', 'l2'], 'classifier__C': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59]}, {'classifier': [LinearDiscriminantAnalysis(n_components=None, priors=None, shrinkage=None,
                           solver='svd', store_covariance=False, tol=0.0001)]}, {'classifier': [GaussianNB(priors=None, var_smoothing=1e-09)]}, {'classifier': [KNeighborsClassifier(algorithm='auto', leaf_size=30, metric='minkowski',
                     metric_params=None, n_jobs=-1, n_neighbors=5, p=2,
                     weights='uniform')], 'classifier__n_neighbors': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59]}, {'classifier': [DecisionTreeClassifier(class_weight=None, criterion='gini', max_depth=None,
                       max_features=None, max_leaf_nodes=None,
                       min_impurity_decrease=0.0, min_impurity_split=None,
                       min_samples_leaf=1, min_samples_split=2,
                       min_weight_fraction_leaf=0.0, presort=False,
                       random_state=27, splitter='best')], 'classifier__max_features': ['auto', 'log2', None]}, {'classifier': [RandomForestClassifier(bootstrap=True, class_weight=None, criterion='gini',
                       max_depth=None, max_features='auto', max_leaf_nodes=None,
                       min_impurity_decrease=0.0, min_impurity_split=None,
                       min_samples_leaf=1, min_samples_split=2,
                       min_weight_fraction_leaf=0.0, n_estimators='warn',
                       n_jobs=-1, oob_score=False, random_state=27, verbose=0,
                       warm_start=False)], 'classifier__n_estimators': [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299], 'classifier__max_features': ['auto', 'log2', None]}, {'classifier': [LGBMClassifier(boosting_type='gbdt', class_weight=None, colsample_bytree=1.0,
               importance_type='split', learning_rate=0.1, max_depth=-1,
               min_child_samples=20, min_child_weight=0.001, min_split_gain=0.0,
               n_estimators=100, n_jobs=-1, num_leaves=31, objective=None,
               random_state=27, reg_alpha=0.0, reg_lambda=0.0, silent=True,
               subsample=1.0, subsample_for_bin=200000, subsample_freq=0)], 'classifier__n_estimators': [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299]}, {'classifier': [XGBClassifier(base_score=0.5, booster='gbtree', colsample_bylevel=1,
              colsample_bynode=1, colsample_bytree=1, gamma=0,
              learning_rate=0.1, max_delta_step=0, max_depth=3,
              min_child_weight=1, missing=None, n_estimators=100, n_jobs=-1,
              nthread=None, objective='binary:logistic', random_state=27,
              reg_alpha=0, reg_lambda=1, scale_pos_weight=1, seed=None,
              silent=None, subsample=1, verbosity=1)], 'classifier__n_estimators': [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299], 'classifier__booster': ['dart', 'gblinear', 'gbtree']}, {'classifier': [AdaBoostClassifier(algorithm='SAMME.R', base_estimator=None, learning_rate=1.0,
                   n_estimators=50, random_state=None)], 'classifier__n_estimators': [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299]}]]

        # Assertion
        out_grid = make_parameter_grids(constant_grids, competing_grids)
        compare_to = [{'scaler': [IdentityTransformer()], 'reduce_dim': [IdentityTransformer()], 'classifier': [LogisticRegression(C=1.0, class_weight=None, dual=False, fit_intercept=True,
                   intercept_scaling=1, l1_ratio=None, max_iter=100,
                   multi_class='warn', n_jobs=None, penalty='l2',
                   random_state=27, solver='warn', tol=0.0001, verbose=0,
                   warm_start=False)], 'classifier__penalty': ['l1', 'l2'], 'classifier__C': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59]}, {'scaler': [IdentityTransformer()], 'reduce_dim': [IdentityTransformer()], 'classifier': [LinearDiscriminantAnalysis(n_components=None, priors=None, shrinkage=None,
                           solver='svd', store_covariance=False, tol=0.0001)]}, {'scaler': [IdentityTransformer()], 'reduce_dim': [IdentityTransformer()], 'classifier': [GaussianNB(priors=None, var_smoothing=1e-09)]}, {'scaler': [IdentityTransformer()], 'reduce_dim': [IdentityTransformer()], 'classifier': [KNeighborsClassifier(algorithm='auto', leaf_size=30, metric='minkowski',
                     metric_params=None, n_jobs=-1, n_neighbors=5, p=2,
                     weights='uniform')], 'classifier__n_neighbors': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59]}, {'scaler': [IdentityTransformer()], 'reduce_dim': [IdentityTransformer()], 'classifier': [DecisionTreeClassifier(class_weight=None, criterion='gini', max_depth=None,
                       max_features=None, max_leaf_nodes=None,
                       min_impurity_decrease=0.0, min_impurity_split=None,
                       min_samples_leaf=1, min_samples_split=2,
                       min_weight_fraction_leaf=0.0, presort=False,
                       random_state=27, splitter='best')], 'classifier__max_features': ['auto', 'log2', None]}, {'scaler': [IdentityTransformer()], 'reduce_dim': [IdentityTransformer()], 'classifier': [RandomForestClassifier(bootstrap=True, class_weight=None, criterion='gini',
                       max_depth=None, max_features='auto', max_leaf_nodes=None,
                       min_impurity_decrease=0.0, min_impurity_split=None,
                       min_samples_leaf=1, min_samples_split=2,
                       min_weight_fraction_leaf=0.0, n_estimators='warn',
                       n_jobs=-1, oob_score=False, random_state=27, verbose=0,
                       warm_start=False)], 'classifier__n_estimators': [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299], 'classifier__max_features': ['auto', 'log2', None]}, {'scaler': [IdentityTransformer()], 'reduce_dim': [IdentityTransformer()], 'classifier': [LGBMClassifier(boosting_type='gbdt', class_weight=None, colsample_bytree=1.0,
               importance_type='split', learning_rate=0.1, max_depth=-1,
               min_child_samples=20, min_child_weight=0.001, min_split_gain=0.0,
               n_estimators=100, n_jobs=-1, num_leaves=31, objective=None,
               random_state=27, reg_alpha=0.0, reg_lambda=0.0, silent=True,
               subsample=1.0, subsample_for_bin=200000, subsample_freq=0)], 'classifier__n_estimators': [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299]}, {'scaler': [IdentityTransformer()], 'reduce_dim': [IdentityTransformer()], 'classifier': [XGBClassifier(base_score=0.5, booster='gbtree', colsample_bylevel=1,
              colsample_bynode=1, colsample_bytree=1, gamma=0,
              learning_rate=0.1, max_delta_step=0, max_depth=3,
              min_child_weight=1, missing=None, n_estimators=100, n_jobs=-1,
              nthread=None, objective='binary:logistic', random_state=27,
              reg_alpha=0, reg_lambda=1, scale_pos_weight=1, seed=None,
              silent=None, subsample=1, verbosity=1)], 'classifier__n_estimators': [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299], 'classifier__booster': ['dart', 'gblinear', 'gbtree']}, {'scaler': [IdentityTransformer()], 'reduce_dim': [IdentityTransformer()], 'classifier': [AdaBoostClassifier(algorithm='SAMME.R', base_estimator=None, learning_rate=1.0,
                   n_estimators=50, random_state=None)], 'classifier__n_estimators': [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299]}]

        # self.assertEqual(out_grid, compare_to)


if __name__ == '__main__':
    unittest.main()
