"""
Module for backend unit tests.
"""
# Vanilla
from copy import deepcopy
​
# Import Data Manipulation
import numpy as np
import pandas as pd
​
# Import Testing Framework
import unittest
from numpy.testing import assert_array_equal
​
# Pipeline Models
from sklearn.naive_bayes import GaussianNB                                 # Base
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from lightgbm import LGBMClassifier
from xgboost import XGBClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
import sample_models
​
​
# Test Components
from engine_1858.model_utils import splitter, switch_out_models, switch_out_scalers,switch_out_dim_red, reset_indicies
​
​
​
​
class TestModelUtils(unittest.TestCase):
    """ Class to Test ModelUtils """
​
    # Set Test Data
    test_xmat = pd.DataFrame([[12, 15, 6.3, np.nan, 1],
                              [7, 2, np.nan, 1, 1],
                              [np.nan, 5, 12.1, 1, 1],
                              [3, np.nan, 6.1, 0, 1],
                              [12, 15, 6.3, np.nan, 2],
                              [7, 2, np.nan, 1, 2],
                              [np.nan, 5, 12.1, 1, 2],
                              [3, np.nan, 6.1, 0, 2]],
                             columns=['c0', 'c1', 'c2', 'c3', 'species'])
​
    test_out = pd.DataFrame([[12, 15, 6.3, np.nan, 1],
                              [7, 2, np.nan, 1, 1],
                              [np.nan, 5, 12.1, 1, 1],
                              [3, np.nan, 6.1, 0, 1],
                              [12, 15, 6.3, np.nan, 2],
                              [7, 2, np.nan, 1, 2],
                              [np.nan, 5, 12.1, 1, 2],
                              [3, np.nan, 6.1, 0, 2]],
                             columns=['c0', 'c1', 'c2', 'c3', 'species'])
​
    tag_dict = dict(binary=['c3'],
                    continuous=['c2'],
                    integer=['c0', 'c1'])
​
    # Test 1 - splitter
    def test_splitter(self, data=test_xmat):
        """ Test splitter. """
        # Instantiate
        out = splitter("tt", data, target_col, 0.3, stratify)
​
        # Assertion
        assert_array_equal(test_out, data)
​
    # Test 2 - reset_indicies
    def reset_indicies(self, data=test_xmat):
        """ Test the reset_indicies """
​
        # Instantiate
        out = reset_indicies(data)
​
        # Assertion
        assert_array_equal(test_out, data)
​
    # Test 3 - switch_out_models
    def test_switch_out_models(self,data=test_xmat):
        """ Test the switch_out_models """
​
        # Instantiate
        dataframe = switch_out_models(model_dict_list, model_object_dict)
​
        # Assertion
        assert_array_equal(test_out, data)
​
    # Test 4 - switch_out_dim_red
    def test_switch_out_dim_red(self,data=test_xmat):
        """ Test the switch_out_dim_red """
​
        # Instantiate
        out = switch_out_dim_red(dim_reduction_dict, dim_reduction_objects)
​
        # Assertion
        assert_array_equal(test_out, data)
​
    # Test 5 - switch_out_scalers
    def test_switch_out_scalers(self,data=test_xmat):
        """ Test the switch_out_scalers """
​
        # Instantiate
        out = switch_out_scalers(scaler_dict, scaler_object_dict)
​
        # Assertion
        assert_array_equal(test_out, data)
​
if __name__ == '__main__':
    unittest.main()