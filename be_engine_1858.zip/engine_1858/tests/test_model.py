"""
Module for backend unit tests.
"""
# Vanilla
from copy import deepcopy

# Import Data Manipulation
import numpy as np
import pandas as pd

# Import Testing Framework
import unittest
from numpy.testing import assert_array_equal

# Pipeline Models
from sklearn.naive_bayes import GaussianNB                                 # Base
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from lightgbm import LGBMClassifier
from xgboost import XGBClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
import sample_models


# Test Components
from engine_1858.estimator import DELWPModel




class TestDELWPModel(unittest.TestCase):
    """ Class to Test DELWPModel """

    # Set Test Data
    test_xmat = pd.DataFrame([[12, 15, 6.3, np.nan, 1],
                              [7, 2, np.nan, 1, 1],
                              [np.nan, 5, 12.1, 1, 1],
                              [3, np.nan, 6.1, 0, 1],
                              [12, 15, 6.3, np.nan, 2],
                              [7, 2, np.nan, 1, 2],
                              [np.nan, 5, 12.1, 1, 2],
                              [3, np.nan, 6.1, 0, 2]],
                             columns=['c0', 'c1', 'c2', 'c3', 'species'])

    test_out = pd.DataFrame([[12, 15, 6.3, np.nan, 1],
                              [7, 2, np.nan, 1, 1],
                              [np.nan, 5, 12.1, 1, 1],
                              [3, np.nan, 6.1, 0, 1],
                              [12, 15, 6.3, np.nan, 2],
                              [7, 2, np.nan, 1, 2],
                              [np.nan, 5, 12.1, 1, 2],
                              [3, np.nan, 6.1, 0, 2]],
                             columns=['c0', 'c1', 'c2', 'c3', 'species'])

    predict_data = np.array([[12.0, 15.0, 6.3, 1.0, 1.0],
                               [7.0, 2.0, 8.166666666666666, 1.0, 1.0],
                               [7.0, 5.0, 12.1, 1.0, 1.0],
                               [3.0, 5.0, 6.1, 0.0, 1.0],
                               [12.0, 15.0, 6.3, 1.0, 2.0],
                               [7.0, 2.0, 8.166666666666666, 1.0, 2.0],
                               [7.0, 5.0, 12.1, 1.0, 2.0],
                               [3.0, 5.0, 6.1, 0.0, 2.0]])

    tag_dict = dict(binary=['c3'],
                    continuous=['c2'],
                    integer=['c0', 'c1'])

    search_parameters = dict(
        scoring="roc_auc",
        n_jobs=4,
        n_iter=5,
        verbose=2,
        cv=3,
        refit=True,
        return_train_score=True,
    )

    scaler_set = {'scaler': ['none']}
    dimensionality_reduction_set = {'reduce_dim': ['none']}

    configuration_dict = {
        "search_parameters": search_parameters,
        "scaler_set": scaler_set,
        "dimensionality_reduction_set": dimensionality_reduction_set,
        "model_config_list": sample_models.models,
    }

    cond_imp_args = dict(tag_dict=tag_dict, conditioning_column=tag_dict["id"][0])
    binariser_args = dict(binary_columns=tag_dict["binary"], id_col="species")
    cc_pipe_kwargs = dict(fit_arg_list=[cond_imp_args, binariser_args])

    split_type = "tt"

    split_kwargs = {
        "test_size": 0.33,
        "stratify": ["species", "reliability"],
    }

    model = DELWPModel(data, tag_dict, configuration_dict, cc_pipe_kwargs, split_type, split_kwargs)

    # Test 1 - train
    def test_train(self, data=test_xmat):
        """ Test Train. """
        # Instantiate
        out = model.train()

        # Assertion
        assert_array_equal(test_out, data)

    # Test 2 - predict
    def test_predict(self):
        """ Test predict """

        # Instantiate
        dataframe = model.predict()

        # Assertion
        compare_to = np.array([[12.0, 15.0, 6.3, 1.0, 1.0],
                               [7.0, 2.0, 8.166666666666666, 1.0, 1.0],
                               [7.0, 5.0, 12.1, 1.0, 1.0],
                               [3.0, 5.0, 6.1, 0.0, 1.0],
                               [12.0, 15.0, 6.3, 1.0, 2.0],
                               [7.0, 2.0, 8.166666666666666, 1.0, 2.0],
                               [7.0, 5.0, 12.1, 1.0, 2.0],
                               [3.0, 5.0, 6.1, 0.0, 2.0]])
        assert_array_equal(predict_data, compare_to)


if __name__ == '__main__':
    unittest.main()