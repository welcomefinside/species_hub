#!/usr/bin/env python

"""Setup File for Engine 1858, a library for perpetual model re-estimation."""
import setuptools
from numpy.distutils.core import setup

setup(name='engine_1858',
      version='0.1',
      description='ML Library for perpetual model re-estimation.',
      author='Automated Learning Technologies (Monash University FIT3163 - Team 14)',
      author_email='ldes0002@student.monash.edu',
      packages=['engine_1858'])
